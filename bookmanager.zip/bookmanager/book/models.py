from django.db import models
# 2.发现找不到Django模块 终端命令which python + 设置解释器
# 将解释器的地址设置为 /home/ubuntu/.virtualenvs/py3_1223/bin/python

# Create your models here.

# 3.1定义模型类
class BookInfo(models.Model):
    # id Django会自动为我们创建故不需手动写入
    name=models.CharField(max_length=10)

    # 优化页面模型类展示
    def __str__(self):
        return self.name

class PeopleInfo(models.Model):
    # id Django会自动为我们创建故不需手动写入
    name=models.CharField(max_length=10)
    gender=models.BooleanField()  # True/False
    # 外键，关联BookInfo类
    book=models.ForeignKey(BookInfo,on_delete=models.CASCADE)

    # 优化页面模型类展示
    def __str__(self):
        return self.name
    
    
# 3.2模型迁移（创建数据表）