from django.shortcuts import render
# 导入HttpResponse,HttpRequest模块
from django.http import HttpResponse
from django.http import HttpRequest
# Create your views here.
def index(request):  #　定义视图函数
    return HttpResponse('欢迎来到index页面！')
    # 必须返回HttpResponse对象及响应信息

def index2(request):
    data = {
    'show':'元旦 快乐~~~~'
    }
    return render(request,'book/index2.html',context=data)
