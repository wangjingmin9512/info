# 配置ＵＲＬｃｏｎｆ 
from django.urls import path
# 导入视图函数名
from book.views import index
from book.views import index2
urlpatterns = [
    # path中第一个参数是用户访问路由，第二个参数是视图函数名
    path('index/', index),
    # path('', index),
    # html页面路径
    path('', index2)
]